#include <SPI.h>
#include "nRF24L01.h"
#include "RF24.h"
#include "printf.h"

RF24 radio(7,8);
// Radio pipe addresses for the 2 nodes to communicate.
const uint64_t pipes[2] = { 0xF0F0F0F0E1LL, 0xF0F0F0F0D2LL };

void initRadio()
{
  printf_begin();
  radio.begin();

  // optionally, increase the delay between retries & # of retries
  radio.setRetries(15,15);

  // optionally, reduce the payload size.  seems to
  // improve reliability
  //radio.setPayloadSize(8);
  radio.openWritingPipe(pipes[1]);
  radio.openReadingPipe(1,pipes[0]);

  radio.startListening();
  radio.printDetails();  
}


bool checkRadio(void *data, int len)
{
  bool res = false;

  if ( radio.available() )
  {
    res = radio.read( &data, len );
    /*radio.stopListening();
    radio.write( &got_time, sizeof(unsigned long) );
    radio.startListening();*/
  }
  return res;
}
void closeRadio()
{
  radio.stopListening();  
}


void testRadio()
{
  char teststr[3];
  while(1)
  {
    if(checkRadio(teststr,3))
    {
      printf("%s",teststr);  
    }
  }
}

